# MATE-2105: espacio opcional de trabajo para laboratorios

Este repositorio sirve para guardar versiones de tus notebooks y ejecutar una
validación visible en GitHub. **La entrega oficial sigue siendo el archivo
`.ipynb` cargado en Gradescope desde Bloque Neón.** Un `push` en GitHub no cuenta
como entrega.

## Ruta corta en el navegador

1. Acepta el enlace de GitHub Classroom enviado por el profesor.
2. En el repositorio creado para ti, abre **Code > Codespaces > Create codespace**.
3. Coloca el notebook en `notebooks/` sin cambiar el fragmento `lab01`, `lab02`,
   `lab03`, `lab04` o `lab05` de su nombre.
4. Trabaja en Jupyter dentro de VS Code. Reinicia el kernel y ejecuta todas las
   celdas antes de cerrar.
5. En **Source Control**, escribe un mensaje breve y selecciona **Commit & Push**.
6. Revisa que la acción `Validar notebook` aparezca en verde.
7. Descarga el `.ipynb` terminado y súbelo a Gradescope antes de la fecha límite.

## Ruta local para quien ya usa Git

```bash
git clone URL_DE_TU_REPOSITORIO
cd NOMBRE_DEL_REPOSITORIO
python -m pip install -r requirements.txt
python validar_entrega.py notebooks/tu_notebook.ipynb
git add notebooks/tu_notebook.ipynb
git commit -m "Completa laboratorio"
git push
```

La validación revisa estructura, celdas pendientes, errores visibles y respuesta
manual. No contiene pruebas ocultas y no anticipa la nota del autograder.

## Qué no debes subir

- claves, tokens o contraseñas;
- datos personales o restringidos;
- archivos de más de 50 MB;
- soluciones de otras personas;
- entornos `.venv`, cachés o datasets que ya estén publicados en el curso.
