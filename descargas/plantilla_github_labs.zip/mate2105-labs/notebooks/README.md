# Notebooks

Coloca aquí el notebook de trabajo. Conserva en el nombre el fragmento del
laboratorio, por ejemplo `apellido_nombre_lab01_regresion_gradiente.ipynb`.
