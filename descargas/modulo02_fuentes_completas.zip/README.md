# Módulo 2: Redes neuronales desde primeros principios

Este módulo cubre las semanas 7 a 10 de MATE-2105. Construye redes neuronales desde una neurona logística hasta una red densa de una capa oculta, backpropagation, diagnóstico de entrenamiento, optimizadores y comparación con PyTorch.

## Estructura

```text
modulo02_redes_neuronales/
├── capitulo01_perceptron_forward.qmd
├── capitulo02_backpropagation.qmd
├── capitulo03_diagnostico_regularizacion.qmd
├── capitulo04_optimizadores_pytorch.qmd
├── capitulo05_ejercicios_integradores.qmd
├── laboratorios/
├── notebooks/
├── slides/
├── recursos/
└── scripts/
```

## Render

```bash
quarto render
quarto render slides/semana07_presentacion.qmd
quarto render slides/semana08_presentacion.qmd
quarto render slides/semana09_presentacion.qmd
quarto render slides/semana10_presentacion.qmd
```

## Evaluación

El módulo incluye Lab 3 sobre redes neuronales desde cero. Para trabajar como estudiante, usa el notebook publicado en `laboratorios/` y revisa la rúbrica correspondiente.

Los materiales privados de calificación no se distribuyen en los paquetes públicos.
