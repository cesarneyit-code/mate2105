# Módulo 2: Redes neuronales desde primeros principios

Este módulo cubre las semanas 7 a 10 de MATE-2105. Construye redes neuronales desde una neurona logística hasta una red densa de una capa oculta, backpropagation, diagnóstico de entrenamiento, optimizadores y comparación con PyTorch.

## Estructura

```text
modulo02_redes_neuronales/
├── capitulo01_perceptron_forward.qmd
├── capitulo02_backpropagation.qmd
├── capitulo03_diagnostico_regularizacion.qmd
├── capitulo04_optimizadores_pytorch.qmd
├── capitulo05_ejercicios_integradores.qmd
├── laboratorios/
├── notebooks/
├── slides/
├── docente/
├── recursos/
├── autograding/
└── scripts/
```

## Render

```bash
quarto render
quarto render slides/semana07_presentacion.qmd
quarto render slides/semana08_presentacion.qmd
quarto render slides/semana09_presentacion.qmd
quarto render slides/semana10_presentacion.qmd
```

## Autograding

```bash
python scripts/run_local_autograder.py lab03 laboratorios/lab03_redes_desde_cero_solucion.ipynb
```

La parte manual queda restringida a interpretación de curvas, diagnóstico y comparación técnica.
