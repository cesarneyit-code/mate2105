# MATE-2105 Módulo 5

Módulo de cierre del curso: Parcial 2, reproducibilidad, comunicación técnica, proyecto final y defensa.

## Estructura

- `index.qmd` y capítulos: libro del módulo.
- `slides/`: presentaciones semanas 14, 15 y 16.
- `notebooks/`: notebooks de clase.
- `laboratorios/`: Parcial 2 autograded, rúbricas y plantillas.
- `autograding/`: pruebas privadas y empaquetado Gradescope.
- `docente/`: guiones de clase y checklist.
- `recursos/`: guías de proyecto final, defensa y autograding.

## Validación local

```bash
quarto render
quarto render slides/semana14_presentacion.qmd
quarto render slides/semana15_presentacion.qmd
quarto render slides/semana16_presentacion.qmd
../modulo01_regresion_optimizacion/.venv/bin/python scripts/run_local_autograder.py parcial02 laboratorios/parcial02_autograded_solucion.ipynb
```

## Publicación

Usar:

```bash
bash sitio_curso/scripts/sync_modulo05.sh
```

