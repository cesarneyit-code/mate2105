# Módulo 5: Cierre, reproducibilidad y defensa

Este módulo cubre las semanas 14 a 16 de MATE-2105. Cierra el curso con Parcial 2, reproducibilidad, comunicación técnica, entrega del proyecto final y defensa oral individual.

## Estructura

```text
modulo05_cierre_reproducibilidad/
├── capitulo01_parcial2_sintesis.qmd
├── capitulo02_reproducibilidad_tracking.qmd
├── capitulo03_comunicacion_tecnica.qmd
├── capitulo04_entrega_defensa.qmd
├── capitulo05_ejercicios_integradores.qmd
├── laboratorios/
├── notebooks/
├── slides/
├── recursos/
└── scripts/
```

## Artefactos Principales

- Libro del módulo: `index.qmd` y capítulos.
- Parcial 2 autograded: `laboratorios/parcial02_autograded.ipynb`.
- Guía de proyecto final: `recursos/guia_proyecto_final.qmd`.
- Guía de defensa oral: `recursos/guia_defensa_oral.qmd`.
- Plantilla de reporte final: `recursos/plantilla_reporte_final.qmd`.
- Guías de cierre, entrega y defensa.

## Validación local

```bash
quarto render
quarto render slides/semana14_presentacion.qmd
quarto render slides/semana15_presentacion.qmd
quarto render slides/semana16_presentacion.qmd
```

El módulo incluye Parcial 2, proyecto final y defensa individual. Los materiales privados de calificación no se distribuyen en los paquetes públicos.

## Publicación

Usar:

```bash
bash sitio_curso/scripts/sync_modulo05.sh
```
