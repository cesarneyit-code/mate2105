# Módulo 4: Aprendizaje no supervisado y estructura latente

Este módulo cubre las semanas 12 y 13 de MATE-2105. Estudia SVD, PCA, K-Means y recomendación básica con énfasis en interpretación, evaluación y límites aplicados.

## Render

```bash
quarto render
quarto render slides/semana12_presentacion.qmd
quarto render slides/semana13_presentacion.qmd
```

## Autograding

```bash
python scripts/run_local_autograder.py lab05 laboratorios/lab05_no_supervisado_solucion.ipynb
```
