# Módulo 4: Aprendizaje no supervisado y estructura latente

Este módulo cubre las semanas 12 y 13 de MATE-2105. Estudia SVD, PCA, K-Means y recomendación básica con énfasis en interpretación, evaluación y límites aplicados.

## Estructura

```text
modulo04_no_supervisado/
├── capitulo01_svd_pca.qmd
├── capitulo02_kmeans_clustering.qmd
├── capitulo03_recomendacion_latente.qmd
├── capitulo04_ejercicios_integradores.qmd
├── laboratorios/
├── notebooks/
├── slides/
├── recursos/
└── scripts/
```

## Render

```bash
quarto render
quarto render slides/semana12_presentacion.qmd
quarto render slides/semana13_presentacion.qmd
```

## Evaluación

El módulo incluye Lab 5 sobre aprendizaje no supervisado. Para trabajar como estudiante, usa el notebook publicado en `laboratorios/` y revisa la rúbrica correspondiente.

Los materiales privados de calificación no se distribuyen en los paquetes públicos.

## Uso Docente

La preparación docente se mantiene en el repositorio privado del curso.

## Publicación

Para sincronizar el módulo con el portal:

```bash
bash sitio_curso/scripts/sync_modulo04.sh
```
