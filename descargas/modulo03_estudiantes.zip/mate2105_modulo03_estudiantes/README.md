# Módulo 3: Estrategia ML, diagnóstico y análisis de errores

Este módulo cubre la semana 11 de MATE-2105. Su función es convertir modelos entrenables en decisiones técnicas defendibles mediante métricas, particiones, validación cruzada, curvas de aprendizaje, error analysis y diagnóstico de data mismatch.

## Render

```bash
quarto render
quarto render slides/semana11_presentacion.qmd
```

## Autograding

```bash
python scripts/run_local_autograder.py lab04 laboratorios/lab04_diagnostico_modelos_solucion.ipynb
```

La parte manual evalúa diagnóstico y recomendación técnica.
