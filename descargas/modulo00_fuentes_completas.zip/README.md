# Módulo 0: Arranque y lenguaje común

Este directorio contiene el primer módulo operativo de MATE-2105.

El objetivo del módulo es que los estudiantes entiendan la promesa del curso, configuren el flujo mínimo de trabajo y ejecuten un primer ciclo aplicado de ciencia de datos: pregunta, datos, modelo, métrica, diagnóstico y decisión.

## Estructura

```text
modulo00_arranque/
├── _quarto.yml
├── index.qmd
├── capitulo00_libro_estudiantes.qmd
├── texto_estudiantes.qmd
├── styles.css
├── requirements.txt
├── scripts/
│   └── check_env.py
├── slides/
│   └── semana01_presentacion.qmd
├── docente/
│   ├── semana01_guion_clase.md
│   ├── semana01_notas_docente.md
│   ├── checklist_modulo00.md
│   └── revision_final_modulo00.md
├── laboratorios/
│   ├── semana01_lab.qmd
│   ├── semana01_lab.ipynb
│   └── semana01_rubrica.md
├── notebooks/
│   └── semana01_live_coding.ipynb
└── recursos/
    ├── configuracion_entorno.qmd
    ├── guia_proyecto.qmd
    └── politica_ia.qmd
```

## Cómo renderizar

Desde este directorio:

```bash
quarto render
```

Para renderizar solo la presentación:

```bash
quarto render slides/semana01_presentacion.qmd
```

Los documentos Quarto están configurados para no ejecutar código automáticamente. Para trabajar los notebooks con estudiantes se recomienda crear un entorno Python e instalar las dependencias:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python scripts/check_env.py
```

## Artefactos principales

- Libro del módulo: `index.qmd`, `texto_estudiantes.qmd`, laboratorio, guía de proyecto y política de IA.
- Capítulo tipo libro de texto: `capitulo00_libro_estudiantes.qmd`.
- Guía de configuración: `recursos/configuracion_entorno.qmd`.
- Presentación completa: `slides/semana01_presentacion.qmd`.
- Guion docente: `docente/semana01_guion_clase.md`.
- Laboratorio diagnóstico: `laboratorios/semana01_lab.qmd` y `laboratorios/semana01_lab.ipynb`.
- Notebook de live coding: `notebooks/semana01_live_coding.ipynb`.

## Fuentes y artefactos generados

Los archivos `.qmd`, `.md`, `.ipynb`, `.py`, `.yml` y `.scss` son fuentes editables. Las carpetas `_book/`, `.quarto/` y `slides/semana01_presentacion_files/` son salidas o cache de renderizado.
