# Semana 1: guion de clase

Curso: MATE-2105 Matemáticas y Algoritmos en Ciencia de Datos Aplicada  
Módulo: 0, Arranque y lenguaje común  
Duracion sugerida: dos bloques de 80 minutos  
Modalidad: clase activa con live coding y laboratorio diagnóstico  

## Objetivo docente de la semana

La primera semana debe lograr tres cosas:

1. Fijar la identidad del curso: matemática, algoritmos y aplicación.
2. Hacer visible el ciclo pregunta -> datos -> modelo -> diagnóstico -> decisión.
3. Poner a los estudiantes a ejecutar un primer flujo de ciencia de datos con datos reales.

La semana no debe convertirse en una sesión administrativa larga. La administración aparece solo cuando ayuda a entender cómo se trabajará.

## Preparación previa del profesor

Antes de clase:

- Abrir `slides/semana01_presentacion.qmd` renderizada.
- Abrir `notebooks/semana01_live_coding.ipynb`.
- Verificar que el entorno tenga `numpy`, `pandas`, `scikit-learn` y `matplotlib`.
- Ejecutar `python scripts/check_env.py` desde `modulo00_arranque`.
- Tener a mano `recursos/guia_proyecto.qmd` y `recursos/politica_ia.qmd`.
- Decidir si el laboratorio diagnóstico se entrega en clase o después de clase.
- Revisar `docente/checklist_modulo00.md`.

## Preparación previa del asistente

El asistente debe:

- Revisar el laboratorio diagnóstico.
- Preparar una lista de errores comunes de instalación.
- Ayudar a estudiantes con entorno Python/Jupyter.
- Tomar nota de dudas recurrentes para abrir el segundo bloque.

## Materiales

- Presentación: `slides/semana01_presentacion.qmd`.
- Lectura estudiantes: `texto_estudiantes.qmd`.
- Capítulo de estudio: `capitulo00_libro_estudiantes.qmd`.
- Guía de configuración: `recursos/configuracion_entorno.qmd`.
- Notebook de live coding: `notebooks/semana01_live_coding.ipynb`.
- Laboratorio: `laboratorios/semana01_lab.ipynb` o `laboratorios/semana01_lab.qmd`.
- Rúbrica: `laboratorios/semana01_rubrica.md`.

# Bloque A: identidad del curso y primer ciclo aplicado

Duracion sugerida: 80 minutos.

## 0-8 min: apertura

Profesor:

- Presenta el nombre completo del curso.
- Dice explicitamente que el curso no es un bootcamp de librerías ni un curso teórico aislado.
- Presenta la tesis:

> Vamos a derivar, implementar, comparar con herramientas profesionales y aplicar sobre datos reales.

Estudiantes:

- Escuchan y escriben una expectativa concreta del curso.

## 8-15 min: promesa y contrato intelectual

Profesor:

- Usa las diapositivas "La promesa" y "Lo que este curso no es".
- Explica que el curso alternará entre ejemplos controlados, útiles para revisar código e ideas, y datasets reales o públicos, útiles para discutir interpretación y decisiones.
- Enfatiza que el curso exige matemáticas y criterio aplicado.

Pregunta al grupo:

> Qué sería una mala versión de un curso con este título?

Objetivo:

- Hacer que los estudiantes identifiquen riesgos: solo código, solo teoría, solo métricas, poca interpretación.

## 15-25 min: ciclo de ciencia de datos aplicada

Profesor:

- Presenta el ciclo:

```text
pregunta -> datos -> modelo -> pérdida -> algoritmo
       -> métrica -> diagnóstico -> decisión
```

- Da un ejemplo breve: clasificación médica, precios de vivienda o recomendación.
- Distingue pérdida y métrica.

Estudiantes:

- Responden: en el ejemplo dado, cuál sería la fila, cuál sería `X`, cuál sería `y`.

## 25-35 min: actividad en parejas

Instruccion:

En parejas, propongan un problema con datos reales y respondan:

1. Qué representa una fila?
2. Qué columnas tendría?
3. Qué decisión se quiere informar?
4. Cuál sería una mala métrica?

Profesor:

- Circula y escucha ejemplos.

Asistente:

- Identifica dos ejemplos buenos y uno problematico para discutir.

## 35-45 min: discusion de ejemplos

Profesor:

- Recoge dos o tres respuestas.
- Corrige con cuidado si confunden pregunta aplicada con algoritmo.
- Enfatiza que "predecir algo" no basta; falta decir para qué decisión.

Mensaje clave:

> Un modelo sin decisión es solo un ejercicio computacional.

## 45-55 min: primer dataset

Profesor:

- Presenta `load_wine`.
- Aclara qué es un dataset pequeño, no una aplicación industrial.
- Formula la pregunta:

> Podemos usar mediciones químicas para clasificar el tipo de vino mejor que un baseline trivial?

Estudiantes:

- Predicen qué información necesitan antes de entrenar un modelo.

## 55-75 min: live coding inicial

Profesor:

- Abre `notebooks/semana01_live_coding.ipynb`.
- Ejecuta o escribe:
  - carga de datos;
  - inspeccion de dimensiones;
  - conteo de clases;
  - partición `train/test`;
  - baseline.

Pausas activas:

1. Antes de mirar clases: "creen que estaran balanceadas?"
2. Antes del baseline: "que accuracy podría tener predecir la clase mayoritaria?"

Asistente:

- Ayuda a estudiantes que intentan correr el notebook.

## 75-80 min: cierre del bloque A

Profesor:

- Resume:

```text
Ya tenemos pregunta, datos, partición y baseline.
Todavía no tenemos conclusión.
```

- Deja una pregunta para el descanso:

> Qué tendría que pasar para que un modelo más complejo sea defendible?

# Bloque B: modelo de referencia, interpretación y proyecto

Duracion sugerida: 80 minutos.

## 0-8 min: reapertura con errores comunes

Asistente:

- Presenta 2 o 3 problemas vistos en el bloque A:
  - entorno no configurado;
  - confundir `X` con `y`;
  - creer que accuracy sin baseline es suficiente.

Profesor:

- Conecta esos errores con el ciclo general.

## 8-25 min: modelo de referencia

Profesor:

- Continuan el live coding.
- Construye pipeline:
  - `StandardScaler`;
  - `LogisticRegression`;
  - entrenamiento;
  - predicción.

Nota pedagógica:

- Aclarar que regresión logística se usa hoy como herramienta y se derivara más adelante.

Pregunta:

> Por qué puede ser peligroso usar una herramienta antes de entenderla?

Respuesta esperada:

- Porque se pueden ignorar supuestos, escalamiento, regularización, interpretación y errores.

## 25-40 min: métricas e interpretación

Profesor:

- Calcula accuracy del baseline y del modelo.
- Muestra matriz de confusion.
- Pregunta:

> Qué error sería más preocupante si esto fuera una decisión real?

Estudiantes:

- Escriben una conclusión técnica de dos frases.

Formato:

> El modelo es una primera referencia defendible/no defendible porque supera/no supera el baseline con la métrica ____. Sin embargo, la conclusión está limitada por ____.

## 40-55 min: introduccion del laboratorio diagnóstico

Profesor:

- Abre `laboratorios/semana01_lab.ipynb`.
- Explica que el laboratorio es diagnóstico.
- Muestra las partes:
  - inspeccion;
  - partición;
  - baseline;
  - modelo;
  - reflexion;
  - ideas de proyecto.

Asistente:

- Verifica que los estudiantes puedan abrir el notebook.

Estudiantes:

- Empiezan el laboratorio en clase.

## 55-65 min: proyecto final desde semana 1

Profesor:

- Presenta `recursos/guia_proyecto.qmd`.
- Explica que el proyecto no empieza al final.
- Define lo que deben traer:
  - dos áreas de interés;
  - posibles datasets;
  - pregunta modelable;
  - razón por la que importa.

Mensaje:

> El proyecto no es un notebook largo. Es una decisión técnica defendible sobre datos reales.

## 65-72 min: política de IA

Profesor:

- Presenta `recursos/politica_ia.qmd`.
- Aclara uso permitido:
  - depurar;
  - explicar errores;
  - sugerir pruebas;
  - mejorar redaccion.

- Aclara línea roja:
  - entregar código o conclusiones que no se pueden defender.

## 72-78 min: ticket de salida

Estudiantes entregan en una nota corta:

1. Una cosa que entienden mejor ahora.
2. Una cosa que les preocupa del curso.
3. Una idea inicial de proyecto.

Profesor y asistente:

- Revisan después de clase para ajustar el soporte de la semana 2.

## 78-80 min: cierre

Profesor:

- Repite el estándar:

```text
número -> diagnóstico -> decisión
```

- Anuncia la semana 2:

> Regresión lineal múltiple: de álgebra lineal a datos reales.

# Después de clase

Profesor y asistente:

1. Revisan tickets de salida.
2. Separan problemas en tres categorías:
   - bloqueo técnico;
   - confusion conceptual;
   - ideas de proyecto no modelables.
3. Preparan una intervencion corta para abrir la Semana 2.
4. Identifican estudiantes que necesitan soporte de entorno antes del primer laboratorio evaluado.

# Plan de contingencia

Si hay problemas fuertes de instalación:

- No sacrificar la identidad del curso.
- El profesor corre el live coding en pantalla.
- Los estudiantes completan interpretaciones en parejas.
- El asistente organiza una franja de soporte técnico posterior.

Si el tiempo se queda corto:

1. Proteger la identidad del curso.
2. Proteger el ciclo pregunta-datos-modelo-decisión.
3. Proteger baseline vs modelo.
4. Recortar detalles de política de IA y dejarlos como lectura.

Si el grupo viene muy fuerte:

- Agregar `classification_report`.
- Discutir precision/recall por clase.
- Preguntar que ocurriria con clases desbalanceadas.

Si solo hay un bloque disponible:

1. Mantener identidad del curso y ciclo aplicado.
2. Hacer live coding hasta baseline y modelo.
3. Dejar política de IA y proyecto como lectura guiada.
4. Usar el laboratorio como trabajo fuera de clase.

# Evidencia de aprendizaje de la semana

El estudiante habra logrado el objetivo si puede:

- explicar el ciclo aplicado;
- cargar el dataset;
- distinguir `X`, `y`, baseline y modelo;
- interpretar una métrica con cautela;
- proponer una idea inicial de proyecto;
- reconocer que el curso exigira matemáticas y juicio aplicado.
