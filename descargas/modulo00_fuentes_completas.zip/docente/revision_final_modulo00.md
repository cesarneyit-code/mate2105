# Revision profesional del Módulo 0

Fecha de revisión: 2026-07-06  
Alcance: Módulo 0 / Semana 1, "Arranque y lenguaje común"  
Objetivo: dejar el módulo listo para uso con estudiantes y operación docente.

## Criterios de revisión

La revisión se hizo desde tres perspectivas:

1. **Estudiante:** claridad de ruta, carga de lectura, instrucciones de entrega, apoyo técnico, criterios de exito.
2. **Profesor/asistente:** conducción de clase, tiempos, contingencias, evidencias a recoger, consistencia de evaluación.
3. **Calidad técnica:** renderizado Quarto, notebooks validos, estructura de archivos, reproducibilidad mínima.

## Debilidades detectadas y correcciones

| Debilidad | Impacto | Correccion aplicada | Evidencia |
|---|---|---|---|
| La ruta del estudiante no estaba jerarquizada | El estudiante podía no saber que leer primero, que ejecutar y que entregar | Se agregó una tabla "Ruta del estudiante" con tiempos y artefactos | `index.qmd` |
| Habia dos lecturas con roles ambiguos | El capítulo tipo libro y la guía breve podían parecer duplicados | Se redefinio `texto_estudiantes.qmd` como guía de orientación y contrato de trabajo | `texto_estudiantes.qmd` |
| La configuración técnica estaba escondida en el README | Estudiantes con problemas de entorno no tenían guía pedagógica clara | Se creó una guía de configuración con comandos, fallback y reporte de errores | `recursos/configuracion_entorno.qmd` |
| No habia chequeo ejecutable del entorno | El profesor no podía verificar rápidamente dependencias y dataset | Se creó `scripts/check_env.py` con imports y validación de `load_wine` | `scripts/check_env.py` |
| El laboratorio no tenia suficientes auto-chequeos | El estudiante no podía saber si iba bien antes de entregar | Se agregaron valores esperados de dimensiones, conteos, partición y baseline | `laboratorios/semana01_lab.qmd`, `laboratorios/semana01_lab.ipynb` |
| La versión Quarto del laboratorio no tenia espacios de respuesta | Cómo lectura renderizada era menos usable | Se agregaron bloques de respuesta y checklist final | `laboratorios/semana01_lab.qmd` |
| La rúbrica era demasiado compacta | Profesor y asistente podían calificar con criterios distintos | Se ampliaron descriptores, manejo de bloqueos técnicos y comentarios sugeridos | `laboratorios/semana01_rubrica.md` |
| El guion no explicitaba acciones posteriores a clase | La información diagnóstica podía perderse | Se agregó sección "Después de clase" y clasificación de problemas | `docente/semana01_guion_clase.md` |
| Faltaba checklist operativo docente | El profesor podía depender demasiado de memoria durante el arranque | Se creó checklist antes/durante/después de clase | `docente/checklist_modulo00.md` |
| La presentación no mostraba la ruta de semana ni nombre de entrega | Inconsistencia entre clase y libro | Se agregaron diapositivas de ruta y entregable | `slides/semana01_presentacion.qmd` |
| La guía de proyecto podía generar presión prematura | Estudiantes podían pensar que el tema se aprobaba en Semana 1 | Se aclaró que son ideas exploratorias y se agregaron ejemplos de transformación | `recursos/guia_proyecto.qmd` |
| No habia política sobre artefactos generados | Podia confundirse fuente editable con salida de Quarto | Se agregó `.gitignore` y nota en README | `.gitignore`, `README.md` |
| Los notebooks dependían de un kernel nombrado `mate2105` | Podían fallar si el estudiante no registraba exactamente ese kernel | Se cambió metadata a `python3` y se dejó el kernel nombrado como opción | `*.ipynb`, `recursos/configuracion_entorno.qmd` |

## Fortalezas preservadas

- La identidad del curso sigue clara: matemática, implementación, herramientas profesionales y datos reales.
- El Módulo 0 no se reduce a administración; contiene un ciclo aplicado completo.
- El laboratorio mantiene carga razonable y diagnóstica.
- El proyecto final aparece desde la Semana 1 sin exigir una decisión prematura.
- La política de IA permite apoyo sin renunciar a defensa técnica individual.

## Criterios de versión final

Para considerar el Módulo 0 listo, deben cumplirse estas condiciones:

1. El libro Quarto renderiza sin ejecutar código.
2. La presentación RevealJS renderiza.
3. Los notebooks son JSON valido.
4. El estudiante puede identificar que leer, que ejecutar y que entregar.
5. El profesor tiene guion, notas, checklist y rúbrica.
6. El laboratorio tiene auto-chequeos y cierre interpretativo.
7. Los problemas técnicos tienen una ruta de reporte y soporte.
8. Los notebooks ejecutan en un entorno limpio con las dependencias de `requirements.txt`.

## Validacion técnica realizada

- `quarto render` genera el libro completo en `_book/index.html`.
- `quarto render slides/semana01_presentacion.qmd` genera la presentación RevealJS.
- `python3 -m json.tool` valida los notebooks como JSON.
- `python scripts/check_env.py` valida dependencias y dataset `load_wine`.
- `jupyter nbconvert --execute` ejecuta completo:
  - `notebooks/semana01_live_coding.ipynb`;
  - `laboratorios/semana01_lab.ipynb`.

## Recomendación de uso

Usar el capítulo tipo libro como lectura conceptual obligatoria. Usar la guía de orientación como contrato de trabajo. Usar el laboratorio como entrega diagnóstica. Usar los tickets de salida y respuestas de proyecto para ajustar la Semana 2.
