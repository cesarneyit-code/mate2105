# Semana 1: paquete Bloque Neón y preparación docente

Curso: MATE-2105 Matemáticas y Algoritmos en Ciencia de Datos Aplicada  
Periodo: 2026-20  
Semana: 1  
Fechas: martes 4 de agosto y jueves 6 de agosto de 2026  
Horario: martes y jueves, 12:00-13:50  
Salón: por confirmar  

Este documento es la lista operativa para dejar lista la primera semana en Bloque Neón/Brightspace y para preparar las dos primeras clases.

## Objetivo operativo

Al terminar la primera semana, cada estudiante debe haber logrado cuatro cosas:

1. Entender la identidad del curso: matemáticas, algoritmos y decisiones con datos.
2. Saber navegar el portal, el libro, la ruta semanal y los materiales.
3. Tener un entorno Python/Jupyter funcional o un reporte técnico claro del bloqueo.
4. Ejecutar el laboratorio diagnóstico y traer dos ideas iniciales de proyecto.

## Estructura sugerida en Bloque Neón

Crear una carpeta o módulo inicial llamado:

```text
00. Inicio del curso - Semana 1
```

Dentro de esa carpeta, publicar en este orden:

| Orden | Elemento | Tipo en Bloque Neón | Enlace o archivo |
|---:|---|---|---|
| 1 | Bienvenida y qué hacer esta semana | Anuncio | texto listo en este documento |
| 2 | Programa oficial del curso | Enlace | https://cesarneyit-code.github.io/mate2105/programa.html |
| 3 | Portal del curso | Enlace | https://cesarneyit-code.github.io/mate2105/ |
| 4 | Cómo navegar el curso | Enlace | https://cesarneyit-code.github.io/mate2105/orientacion.html |
| 5 | Ruta semanal | Enlace | https://cesarneyit-code.github.io/mate2105/ruta.html |
| 6 | Libro del curso | Enlace | https://cesarneyit-code.github.io/mate2105/libro/ |
| 7 | Configuración técnica | Enlace | https://cesarneyit-code.github.io/mate2105/configuracion.html |
| 8 | Materiales Semana 1 | Enlace | https://cesarneyit-code.github.io/mate2105/materiales.html#modulo-0-semana-1 |
| 9 | Presentación Semana 1 | Enlace | https://cesarneyit-code.github.io/mate2105/materiales/modulo00/slides/semana01_presentacion.html |
| 10 | Notebook de clase Semana 1 | Enlace o archivo | https://cesarneyit-code.github.io/mate2105/descargas/modulo00/semana01_live_coding.ipynb |
| 11 | Laboratorio diagnóstico | Tarea | https://cesarneyit-code.github.io/mate2105/descargas/modulo00/semana01_lab.ipynb |
| 12 | Rúbrica del laboratorio diagnóstico | Enlace | https://cesarneyit-code.github.io/mate2105/descargas/modulo00/semana01_rubrica.md |
| 13 | Paquete offline Módulo 0 | Enlace opcional | https://cesarneyit-code.github.io/mate2105/descargas/modulo00_estudiantes.zip |
| 14 | Proyecto final | Enlace | https://cesarneyit-code.github.io/mate2105/proyecto.html |

## Anuncio listo para copiar

Asunto:

```text
Bienvenida a MATE-2105: qué preparar para la primera semana
```

Mensaje:

```text
Hola a todas y todos:

Bienvenidos a MATE-2105 Matemáticas y Algoritmos en Ciencia de Datos Aplicada.

Soy César Galindo (he/him), profesor del Departamento de Matemáticas de la Universidad de los Andes. En este curso vamos a estudiar algoritmos centrales de ciencia de datos desde su estructura matemática, su implementación y su uso aplicado.

El curso combinará explicación matemática, notebooks ejecutables y problemas con datos. Algunas actividades usarán ejemplos pequeños y controlados para revisar que el código funciona; otras usarán datasets reales o públicos para discutir interpretación, limitaciones y decisiones.

Antes de la primera clase del martes 4 de agosto de 2026:

1. Abran el portal del curso:
   https://cesarneyit-code.github.io/mate2105/

2. Lean el programa oficial:
   https://cesarneyit-code.github.io/mate2105/programa.html

3. Revisen la ruta de la Semana 1:
   https://cesarneyit-code.github.io/mate2105/ruta.html#semana-1

4. Abran la guía de configuración técnica:
   https://cesarneyit-code.github.io/mate2105/configuracion.html

Durante la primera semana deben tener listo:

- Python/Jupyter funcionando, o un reporte técnico claro si algo falla.
- El laboratorio diagnóstico descargado:
  https://cesarneyit-code.github.io/mate2105/descargas/modulo00/semana01_lab.ipynb
- Dos ideas posibles de proyecto, cada una con tema o dataset, fuente posible, unidad de observación, pregunta aplicada, decisión que podría informar y riesgo o limitación anticipada.

La entrega diagnóstica sugerida de la Semana 1 será el jueves 6 de agosto de 2026 a las 23:59. Confirmaré en clase si esta entrega será solo formativa o si tendrá puntaje de bajo riesgo.

Nos vemos en clase.

César Galindo
Departamento de Matemáticas
Universidad de los Andes
```

## Tarea lista para crear en Bloque Neón

Título:

```text
Semana 1 - Laboratorio diagnóstico de entorno y ciclo aplicado
```

Disponibilidad sugerida:

```text
Desde la publicación del curso hasta el jueves 6 de agosto de 2026 a las 23:59.
```

Puntaje sugerido:

```text
10 puntos formativos.
```

Si se decide calificar con peso real, mantenerlo como actividad de bajo riesgo. La función principal es diagnosticar entorno, interpretación inicial y preparación para Semana 2.

Instrucciones para estudiantes:

```text
Descarga el notebook del laboratorio diagnóstico:

https://cesarneyit-code.github.io/mate2105/descargas/modulo00/semana01_lab.ipynb

Ejecuta el notebook de arriba hacia abajo. Debes conservar salidas visibles y responder las preguntas de interpretación.

Entrega un archivo .ipynb con tu nombre en el formato:

semana01_lab_apellido_nombre.ipynb

Si tuviste un bloqueo técnico, entrega el notebook o un documento breve con:

1. comando ejecutado;
2. error completo;
3. sistema operativo;
4. versión de Python;
5. qué intentaste para resolverlo.

Además, incluye dos ideas iniciales de proyecto. Cada idea debe tener:

- tema o dataset;
- fuente posible;
- unidad de observación;
- pregunta aplicada;
- decisión que podría informar;
- riesgo o limitación anticipada.

Rúbrica:
https://cesarneyit-code.github.io/mate2105/descargas/modulo00/semana01_rubrica.md
```

## Ticket de salida sugerido

Crear una encuesta corta o pedir respuesta en clase con estas tres preguntas:

```text
1. Qué cosa entiendes mejor después de la primera semana?
2. Qué cosa te preocupa del curso o del entorno técnico?
3. Cuál es una idea inicial de proyecto que te gustaría explorar?
```

Uso docente: clasificar las respuestas en bloqueo técnico, confusión conceptual e idea de proyecto no modelable.

## Qué debes leer antes de dictar

Lectura obligatoria docente:

1. Programa del curso: `sitio_curso/programa.qmd`.
2. Ruta Semana 1: `sitio_curso/ruta.qmd`, sección `#semana-1`.
3. Guion de clase: `modulo00_arranque/docente/semana01_guion_clase.md`.
4. Checklist Módulo 0: `modulo00_arranque/docente/checklist_modulo00.md`.
5. Capítulo 0 del libro: `libro_curso/capitulos/00-lenguaje-comun.qmd`.
6. Configuración técnica: `modulo00_arranque/recursos/configuracion_entorno.qmd`.
7. Guía de proyecto: `modulo00_arranque/recursos/guia_proyecto.qmd`.
8. Política de IA: `modulo00_arranque/recursos/politica_ia.qmd`.
9. Rúbrica del laboratorio: `modulo00_arranque/laboratorios/semana01_rubrica.md`.

Material que debes abrir antes de clase:

1. Presentación Semana 1: `modulo00_arranque/slides/semana01_presentacion.html`.
2. Notebook de clase: `modulo00_arranque/notebooks/semana01_live_coding.ipynb`.
3. Laboratorio diagnóstico: `modulo00_arranque/laboratorios/semana01_lab.ipynb`.
4. Portal publicado: https://cesarneyit-code.github.io/mate2105/
5. Configuración publicada: https://cesarneyit-code.github.io/mate2105/configuracion.html

## Checklist de preparación docente

Siete días antes:

- [ ] Confirmar que Bloque Neón tiene el curso disponible.
- [ ] Publicar anuncio de bienvenida.
- [ ] Publicar programa, portal, ruta, libro, configuración y materiales.
- [ ] Crear tarea del laboratorio diagnóstico.
- [ ] Confirmar si el laboratorio diagnóstico será formativo o tendrá puntos.
- [ ] Revisar que el salón, correo, monitoría y horario de atención estén actualizados si ya fueron confirmados.

Cuarenta y ocho horas antes:

- [ ] Abrir la presentación de Semana 1.
- [ ] Ejecutar el notebook de clase.
- [ ] Ejecutar el laboratorio diagnóstico.
- [ ] Ejecutar chequeo de entorno.
- [ ] Probar enlaces públicos desde una ventana privada del navegador.
- [ ] Preparar una frase corta sobre qué es y qué no es el curso.

Treinta minutos antes:

- [ ] Tener abiertas las diapositivas.
- [ ] Tener abierto Jupyter/JupyterLab con el notebook.
- [ ] Tener abierto el portal y la ruta de Semana 1.
- [ ] Tener lista una respuesta si varios estudiantes no tienen entorno funcional.
- [ ] Tener lista la pregunta de activación:

```text
Qué sería una mala versión de un curso llamado Matemáticas y Algoritmos en Ciencia de Datos Aplicada?
```

## Plan de clase por día

Martes 4 de agosto de 2026:

| Tiempo | Acción | Recurso |
|---:|---|---|
| 0-10 min | Identidad del curso, tesis y contrato intelectual | slides Semana 1 |
| 10-25 min | Ciclo pregunta -> datos -> modelo -> diagnóstico -> decisión | slides Semana 1 |
| 25-40 min | Actividad en parejas: problema con datos reales | tablero o notas |
| 40-55 min | Dataset `load_wine`, filas, columnas, objetivo | notebook de clase |
| 55-75 min | Partición, baseline y primer resultado | notebook de clase |
| 75-80 min | Cierre: número -> diagnóstico -> decisión | ruta Semana 1 |

Jueves 6 de agosto de 2026:

| Tiempo | Acción | Recurso |
|---:|---|---|
| 0-10 min | Errores comunes de entorno y conceptos | notas del martes |
| 10-30 min | Modelo de referencia con `StandardScaler` y `LogisticRegression` | notebook de clase |
| 30-45 min | Métricas, baseline y matriz de confusión | notebook de clase |
| 45-60 min | Presentar laboratorio diagnóstico y rúbrica | lab y rúbrica |
| 60-70 min | Proyecto final desde Semana 1 | guía de proyecto |
| 70-75 min | Política de IA | política de IA |
| 75-80 min | Ticket de salida y anuncio de Semana 2 | Bloque Neón |

## Qué no debes publicar

No publicar en Bloque Neón ni en el portal público:

- soluciones de laboratorios;
- autograders;
- pruebas ocultas;
- zips docentes;
- notebooks con respuestas finales;
- comentarios privados de calificación;
- credenciales, tokens o rutas locales sensibles.

## Después de clase

El jueves 6 o viernes 7 de agosto:

- [ ] Revisar errores de entorno reportados.
- [ ] Identificar estudiantes que necesitan soporte antes de Semana 2.
- [ ] Leer una muestra de conclusiones técnicas.
- [ ] Clasificar ideas de proyecto: modelables, incompletas, no viables.
- [ ] Publicar recordatorio de Semana 2: regresión lineal múltiple y lista corta de datasets.
