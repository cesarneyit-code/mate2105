# Checklist operativo del Módulo 0

Este checklist es para el profesor y el asistente. Su objetivo es reducir improvisación operativa en la primera semana.

## Antes de clase

- [ ] Renderizar el libro Quarto: `quarto render`.
- [ ] Renderizar la presentación: `quarto render slides/semana01_presentacion.qmd`.
- [ ] Ejecutar `python scripts/check_env.py` en el entorno que se usará en clase.
- [ ] Abrir la presentación HTML en el navegador.
- [ ] Abrir el notebook `notebooks/semana01_live_coding.ipynb`.
- [ ] Abrir el laboratorio `laboratorios/semana01_lab.ipynb`.
- [ ] Tener visible la guía de configuración para estudiantes con problemas.
- [ ] Definir canal de entrega del laboratorio.
- [ ] Definir si la rúbrica será formativa o tendrá puntos en la nota.

## Durante clase

- [ ] Presentar explicitamente la identidad del curso.
- [ ] No gastar más de 10 minutos seguidos en administración.
- [ ] Hacer al menos una actividad en parejas.
- [ ] Preguntar por baseline antes de entrenar el modelo.
- [ ] Preguntar por limitaciones antes de cerrar el ejemplo.
- [ ] Registrar errores técnicos recurrentes.
- [ ] Registrar confusiones conceptuales recurrentes.
- [ ] Recoger tickets de salida.

## Después de clase

- [ ] Clasificar problemas de entorno.
- [ ] Identificar estudiantes que requieren apoyo antes de Semana 2.
- [ ] Revisar dos o tres ejemplos de conclusiones técnicas de estudiantes.
- [ ] Revisar ideas iniciales de proyecto y separar las no modelables.
- [ ] Preparar apertura de Semana 2 con errores comunes.

## Criterio de calidad

La Semana 1 fue exitosa si la mayoría del grupo puede explicar:

- qué es una observación;
- que son `X` y `y`;
- qué es un baseline;
- por qué se separa entrenamiento y prueba;
- por qué un número sin contexto no es una conclusión.
