# Semana 1: notas docentes

## Intencion pedagógica

La primera semana debe establecer una cultura de trabajo. El riesgo principal es que los estudiantes salgan pensando que el curso será una introduccion convencional a Python o una charla general sobre inteligencia artificial. La clase debe dejar claro que el curso tiene una identidad propia:

- matemática suficiente para abrir los algoritmos;
- implementación suficiente para no depender ciegamente de librerías;
- aplicación suficiente para tomar en serio datos, métricas y decisiones.

## Mensajes que conviene repetir

1. Un resultado numérico no es una conclusión.
2. Una métrica sin baseline es difícil de interpretar.
3. Un modelo entrenado sin diagnóstico es frágil.
4. Un notebook que no se puede reproducir no es un producto técnico confiable.
5. Una decisión técnica debe poder defenderse oralmente.

## Sobre el dataset `load_wine`

El dataset es pequeño y limpio. No debe venderse como ejemplo de complejidad real. Su función pedagógica es permitir que todos vean un ciclo completo en la primera semana.

Ventajas:

- Viene incluido en `scikit-learn`.
- No requiere descarga externa.
- Tiene varias variables numéricas.
- Tiene tres clases.
- Permite baseline y modelo de referencia rápidamente.

Limitaciones que conviene mencionar:

- Es pequeño.
- Esta muy curado.
- No representa problemas modernos de datos a gran escala.
- No obliga todavía a limpiar datos faltantes o inconsistentes.

La conclusión correcta no es "ya sabemos clasificar vinos", sino:

> Ya sabemos identificar las piezas mínimas de un experimento supervisado y comparar un modelo contra un baseline.

## Sobre usar regresión logística sin derivarla

En la Semana 1 se puede usar regresión logística como herramienta profesional para mostrar el flujo completo. Hay que decir explicitamente que aún no se ha derivado. Esto evita contradiccion con la promesa del curso.

Frase sugerida:

> Hoy usamos este modelo como una caja cerrada para ver el flujo completo. Mas adelante abriremos la caja: pérdida, gradiente, optimización y regularización.

## Sobre instalación

No conviene dejar que los problemas de instalación consuman la primera clase. La solución pragmatica:

- El profesor siempre tiene un entorno funcionando.
- El asistente concentra soporte individual.
- Si un estudiante no puede ejecutar, trabaja con alguien que si pueda.
- Se ofrece una franja corta de soporte después de clase o en monitoria.

## Sobre el proyecto

El proyecto debe aparecer desde la Semana 1, pero no debe exigir decisión inmediata. En esta etapa solo se busca activar búsqueda de problemas y datos.

Buenas ideas de proyecto suelen tener:

- datos disponibles legalmente;
- pregunta clara;
- usuario o decisión identificable;
- métrica defendible;
- tamaño manejable;
- posibilidad de construir baseline.

Alertas tempranas:

- "Quiero usar redes neuronales" no es una pregunta.
- "Quiero predecir acciones" suele ser riesgoso para un curso inicial por ruido, leakage y evaluación temporal.
- Datasets gigantes pueden bloquear más de lo que ensenan.
- Datos sensibles requieren cuidado extra.

## Sobre política de IA

La postura recomendada es permitir IA con trazabilidad y defensa. Prohibirla totalmente suele ser poco realista; permitirla sin reglas destruye la evaluación.

La regla clave:

> Puedes usar ayuda, pero debes poder explicar y defender cada línea relevante, cada métrica y cada conclusión.

## Preguntas utiles para clase

Para distinguir datos y decisión:

- Qué accion cambiaria si el modelo predice alto o bajo?
- Qué error sería más costoso?
- Quien se ve afectado por el modelo?

Para baseline:

- Qué haria alguien sin machine learning?
- Qué predicción trivial debemos superar?
- Si el baseline ya es alto, que nos dice eso del problema?

Para métrica:

- Qué mide?
- Qué ignora?
- Puede ser alta mientras el modelo falla de forma importante?

Para proyecto:

- Cuál es la unidad de observación?
- Hay suficientes datos?
- La variable objetivo esta disponible?
- La pregunta requiere predicción, clasificación, agrupamiento o descripción?

## Evidencias a recoger

Durante la semana conviene guardar:

- tickets de salida;
- dudas de instalación;
- ejemplos de proyectos propuestos;
- errores comunes en el laboratorio;
- frases de interpretación buenas y problematicas.

Esto alimenta la Semana 2 y permite ajustar el nivel del curso.

## Debilidades probables del módulo y como intervenir

| Debilidad observada | Senal en estudiantes | Intervencion recomendada |
|---|---|---|
| Confusion entre lectura conceptual y entrega | Preguntan "que hay que entregar?" después de leer | Remitir al indice del módulo y al checklist del laboratorio |
| Problemas de entorno | No importan `sklearn` o no aparece kernel | Usar `recursos/configuracion_entorno.qmd` y pedir reporte de error completo |
| Métrica sin baseline | Reportan solo accuracy del modelo | Preguntar "contra qué regla simple estas comparando?" |
| Proyecto como herramienta | Proponen "usar redes neuronales" como tema | Pedir unidad de observación, pregunta y decisión |
| Conclusiones exageradas | Dicen que el modelo "sirve" sin limitaciones | Exigir métrica, datos, baseline y limitacion en la misma frase |

## Decisión docente clave

No intentes resolver todos los problemas técnicos durante la clase. La prioridad de la Semana 1 es instalar el marco intelectual del curso y detectar bloqueos. Los bloqueos se resuelven mejor con soporte focalizado después de clase o en monitoria.
