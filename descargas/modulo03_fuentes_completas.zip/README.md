# Módulo 3: Estrategia ML, diagnóstico y análisis de errores

Este módulo cubre la semana 11 de MATE-2105. Su función es convertir modelos entrenables en comparaciones verificables mediante métricas, particiones, validación cruzada, curvas de aprendizaje, error analysis y diagnóstico de data mismatch.

## Estructura

```text
modulo03_estrategia_ml/
├── capitulo01_metricas_particiones.qmd
├── capitulo02_validacion_curvas.qmd
├── capitulo03_error_analysis_data_mismatch.qmd
├── capitulo04_ejercicios_integradores.qmd
├── laboratorios/
├── notebooks/
├── slides/
├── recursos/
└── scripts/
```

## Render

```bash
quarto render
quarto render slides/semana11_presentacion.qmd
```

## Evaluación

El módulo incluye Lab 4 sobre diagnóstico de modelos. Para trabajar como estudiante, usa el notebook publicado en `laboratorios/` y revisa la rúbrica correspondiente.

Los materiales privados de calificación no se distribuyen en los paquetes públicos.

## Uso Docente

La preparación docente se mantiene en el repositorio privado del curso.

## Publicación

Para sincronizar el módulo con el portal:

```bash
bash sitio_curso/scripts/sync_modulo03.sh
```
