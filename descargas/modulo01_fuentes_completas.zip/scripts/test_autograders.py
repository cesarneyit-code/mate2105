#!/usr/bin/env python3
"""Prueba soluciones oficiales y tres entregas adversariales temporales."""

from __future__ import annotations

import json
import subprocess
import sys
import tempfile
from pathlib import Path
from textwrap import dedent

import nbformat as nbf


ROOT = Path(__file__).resolve().parents[1]
RUNNER = ROOT / "scripts" / "run_local_autograder.py"


def write_notebook(path: Path, source: str) -> None:
    notebook = nbf.v4.new_notebook(
        cells=[nbf.v4.new_code_cell(dedent(source).strip())],
        metadata={
            "kernelspec": {
                "display_name": "Python 3",
                "language": "python",
                "name": "python3",
            }
        },
    )
    nbf.write(notebook, path)


def grade(assignment: str, notebook: Path) -> tuple[int, dict]:
    completed = subprocess.run(
        [sys.executable, str(RUNNER), assignment, str(notebook)],
        check=False,
        capture_output=True,
        text=True,
    )
    try:
        result = json.loads(completed.stdout)
    except json.JSONDecodeError as exc:
        raise AssertionError(
            f"Salida no JSON para {assignment}:\n{completed.stdout}\n{completed.stderr}"
        ) from exc
    return completed.returncode, result


def assert_full_score(assignment: str, notebook: Path) -> None:
    returncode, result = grade(assignment, notebook)
    assert returncode == 0, result
    assert result["score"] == result["max_score"], result
    assert abs(result["max_score"] - 10.0) < 1e-9, result


def assert_rejected(
    label: str,
    assignment: str,
    notebook: Path,
    expected_failures: set[str] | None = None,
) -> float:
    returncode, result = grade(assignment, notebook)
    assert returncode != 0, f"{label} fue aceptado: {result}"
    assert result["score"] < result["max_score"], result
    failed = {test["name"] for test in result["tests"] if test["score"] == 0}
    if expected_failures:
        missing = expected_failures - failed
        assert not missing, f"{label}: no fallaron las pruebas esperadas {sorted(missing)}"
    return float(result["score"])


def main() -> None:
    official = {
        "lab01": ROOT / "laboratorios" / "lab01_regresion_gradiente_solucion.ipynb",
        "lab02": ROOT / "laboratorios" / "lab02_regularizacion_clasificacion_solucion.ipynb",
        "parcial01": ROOT / "laboratorios" / "parcial01_autograded_solucion.ipynb",
    }
    for assignment, notebook in official.items():
        assert_full_score(assignment, notebook)

    with tempfile.TemporaryDirectory() as temporary:
        temp = Path(temporary)

        incomplete = temp / "incompleto.ipynb"
        write_notebook(incomplete, "import numpy as np")

        hardcoded = temp / "hardcoded.ipynb"
        write_notebook(
            hardcoded,
            """
            import numpy as np

            def add_intercept(X):
                return np.array([[1.0, 2.0, 4.0], [1.0, 3.0, 9.0]])

            def predict_linear(X, theta):
                return np.array([1.0, 3.0, 5.0])

            def mse_loss(X, y, theta):
                return 0.0

            def normal_equation(X, y):
                return np.array([2.0, 3.0])

            def mse_gradient(X, y, theta):
                return np.zeros_like(theta, dtype=float)

            def gradient_descent(X, y, alpha=0.05, num_steps=1000):
                return np.array([1.0, 2.0]), [1.0] * num_steps
            """,
        )

        leakage = temp / "leakage.ipynb"
        write_notebook(
            leakage,
            """
            import numpy as np
            from sklearn.linear_model import Lasso, Ridge
            from sklearn.metrics import (
                accuracy_score,
                f1_score,
                mean_squared_error,
                precision_score,
                recall_score,
            )
            from sklearn.preprocessing import StandardScaler

            def standardize_from_train(X_train, X_validation, X_test):
                scaler = StandardScaler().fit(
                    np.vstack([X_train, X_validation, X_test])
                )
                return (
                    scaler.transform(X_train),
                    scaler.transform(X_validation),
                    scaler.transform(X_test),
                )

            def sigmoid(z):
                z = np.asarray(z, dtype=float)
                out = np.empty_like(z)
                positive = z >= 0
                out[positive] = 1 / (1 + np.exp(-z[positive]))
                exp_z = np.exp(z[~positive])
                out[~positive] = exp_z / (1 + exp_z)
                return out

            def log_loss_binary(y_true, proba, eps=1e-15):
                y_true = np.asarray(y_true, dtype=float)
                p = np.clip(np.asarray(proba, dtype=float), eps, 1 - eps)
                return float(-np.mean(y_true * np.log(p) + (1 - y_true) * np.log(1 - p)))

            def ridge_closed_form(X, y, alpha):
                X = np.asarray(X, dtype=float)
                y = np.asarray(y, dtype=float)
                penalty = np.eye(X.shape[1])
                penalty[0, 0] = 0.0
                return np.linalg.solve(X.T @ X + alpha * penalty, X.T @ y)

            def select_regularization_alpha(
                X_train,
                y_train,
                X_validation,
                y_validation,
                alphas,
                penalty="ridge",
            ):
                scores = {}
                for alpha in alphas:
                    if penalty == "ridge":
                        model = Ridge(alpha=alpha)
                    else:
                        model = Lasso(alpha=alpha, max_iter=20000, tol=1e-8)
                    model.fit(X_train, y_train)
                    scores[float(alpha)] = mean_squared_error(
                        y_validation, model.predict(X_validation)
                    )
                return min(scores, key=scores.get), scores

            def classification_metrics(y_true, proba, threshold=0.5):
                y_true = np.asarray(y_true).astype(int)
                pred = (np.asarray(proba) >= threshold).astype(int)
                return {
                    "accuracy": float(accuracy_score(y_true, pred)),
                    "precision": float(precision_score(y_true, pred, zero_division=0)),
                    "recall": float(recall_score(y_true, pred, zero_division=0)),
                    "f1": float(f1_score(y_true, pred, zero_division=0)),
                }

            def choose_threshold_for_recall(y_true, proba, min_recall=0.90):
                candidates = np.unique(np.r_[0.0, proba, 1.0])
                valid = []
                for threshold in candidates:
                    pred = (np.asarray(proba) >= threshold).astype(int)
                    recall = recall_score(y_true, pred, zero_division=0)
                    if recall >= min_recall:
                        valid.append(float(threshold))
                return max(valid) if valid else 0.0

            protocol_answers = {
                "fit_scaler_on": "all_data",
                "select_regularization_on": "test",
                "select_threshold_on": "test",
                "test_set_role": "model_selection",
            }
            """,
        )

        scores = {
            "incompleto": assert_rejected("incompleto", "lab01", incomplete),
            "hardcoded": assert_rejected("hardcoded", "lab01", hardcoded),
            "leakage": assert_rejected(
                "leakage",
                "lab02",
                leakage,
                {"standardize_from_train", "evaluation_protocol"},
            ),
        }

    print("OK: soluciones oficiales lab01, lab02 y parcial01 = 10/10.")
    print(
        "OK: entregas adversariales rechazadas: "
        + ", ".join(f"{name}={score:.1f}/10" for name, score in scores.items())
        + "."
    )


if __name__ == "__main__":
    main()
