#!/usr/bin/env python3
"""Genera las versiones estudiante y solución de los laboratorios 1 y 2."""

from __future__ import annotations

from pathlib import Path
import sys
from textwrap import dedent

import nbformat as nbf


ROOT = Path(__file__).resolve().parents[1]
LABS = ROOT / "laboratorios"
sys.path.insert(0, str(ROOT.parent))

from gestion_laboratorios.config import load_lab
from gestion_laboratorios.schema import apply_schema_to_notebook

COMMON_IMPORTS = """\
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.datasets import load_diabetes, load_breast_cancer, make_regression
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression, Ridge, Lasso, LogisticRegression
from sklearn.preprocessing import StandardScaler, PolynomialFeatures
from sklearn.pipeline import make_pipeline
from sklearn.metrics import mean_squared_error, accuracy_score, precision_score, recall_score, f1_score, confusion_matrix, roc_auc_score
"""


def markdown(source: str):
    return nbf.v4.new_markdown_cell(dedent(source).strip())


def code(source: str):
    return nbf.v4.new_code_cell(dedent(source).strip())


def write_notebook(path: Path, cells: list, assignment_id: str, *, solution: bool) -> None:
    notebook = nbf.v4.new_notebook(cells=cells)
    notebook.metadata = {
        "kernelspec": {
            "display_name": "Python 3",
            "language": "python",
            "name": "python3",
        },
        "language_info": {"name": "python", "version": "3"},
    }
    apply_schema_to_notebook(notebook, load_lab(assignment_id), solution=solution)
    nbf.write(notebook, path)


def build_lab01() -> None:
    setup = """\
    RNG = np.random.default_rng(2105)
    X_raw, y = make_regression(
        n_samples=120, n_features=3, noise=8.0, random_state=2105
    )
    X_train_raw, X_test_raw, y_train, y_test = train_test_split(
        X_raw, y, test_size=0.25, random_state=2105
    )
    """
    student_functions = """\
    def add_intercept(X):
        # TODO: devolver X con una primera columna de unos
        raise NotImplementedError


    def predict_linear(X, theta):
        # TODO: devolver X @ theta
        raise NotImplementedError


    def mse_loss(X, y, theta):
        # TODO: devolver 1/(2n) * suma de residuales al cuadrado
        raise NotImplementedError


    def standard_error_mean(values):
        # TODO: estimar el error estándar de la media con sd muestral (ddof=1)
        raise NotImplementedError


    def normal_equation(X, y):
        # TODO: resolver mínimos cuadrados con np.linalg.lstsq
        # El nombre se conserva por compatibilidad con el autograder.
        raise NotImplementedError


    def mse_gradient(X, y, theta):
        # TODO: devolver el gradiente de la pérdida definida arriba
        raise NotImplementedError


    def gradient_descent(X, y, alpha=0.05, num_steps=1000):
        # TODO: devolver theta y una pérdida posterior a cada actualización
        raise NotImplementedError
    """
    solution_functions = """\
    def add_intercept(X):
        X = np.asarray(X, dtype=float)
        return np.c_[np.ones(X.shape[0]), X]


    def predict_linear(X, theta):
        return np.asarray(X, dtype=float) @ np.asarray(theta, dtype=float)


    def mse_loss(X, y, theta):
        X = np.asarray(X, dtype=float)
        y = np.asarray(y, dtype=float)
        theta = np.asarray(theta, dtype=float)
        residual = X @ theta - y
        return float(np.mean(residual**2) / 2)


    def standard_error_mean(values):
        values = np.asarray(values, dtype=float)
        if values.ndim != 1 or len(values) < 2:
            raise ValueError("values debe ser un vector con al menos dos observaciones")
        return float(values.std(ddof=1) / np.sqrt(len(values)))


    def normal_equation(X, y):
        X = np.asarray(X, dtype=float)
        y = np.asarray(y, dtype=float)
        return np.linalg.lstsq(X, y, rcond=None)[0]


    def mse_gradient(X, y, theta):
        X = np.asarray(X, dtype=float)
        y = np.asarray(y, dtype=float)
        theta = np.asarray(theta, dtype=float)
        return X.T @ (X @ theta - y) / len(y)


    def gradient_descent(X, y, alpha=0.05, num_steps=1000):
        X = np.asarray(X, dtype=float)
        y = np.asarray(y, dtype=float)
        theta = np.zeros(X.shape[1], dtype=float)
        history = []
        for _ in range(num_steps):
            theta = theta - alpha * mse_gradient(X, y, theta)
            loss = mse_loss(X, y, theta)
            if not np.isfinite(loss):
                raise FloatingPointError("La pérdida dejó de ser finita")
            history.append(loss)
        return theta, history
    """
    experiment = """\
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train_raw)
    X_test_scaled = scaler.transform(X_test_raw)
    X_train = add_intercept(X_train_scaled)
    X_test = add_intercept(X_test_scaled)

    theta_lstsq = normal_equation(X_train, y_train)
    theta_gd, history = gradient_descent(
        X_train, y_train, alpha=0.05, num_steps=2500
    )

    pred_lstsq = predict_linear(X_test, theta_lstsq)
    pred_gd = predict_linear(X_test, theta_gd)
    pred_baseline = np.full_like(y_test, y_train.mean(), dtype=float)

    model = LinearRegression().fit(X_train_scaled, y_train)
    pred_sklearn = model.predict(X_test_scaled)

    print("MSE baseline:", mean_squared_error(y_test, pred_baseline))
    print("MSE lstsq:", mean_squared_error(y_test, pred_lstsq))
    print("MSE descenso:", mean_squared_error(y_test, pred_gd))
    print("MSE sklearn:", mean_squared_error(y_test, pred_sklearn))
    print("||theta_lstsq - theta_gd||:", np.linalg.norm(theta_lstsq - theta_gd))
    print("||X.T @ residual_train||:", np.linalg.norm(X_train.T @ (y_train - X_train @ theta_lstsq)))
    losses_test = (y_test - pred_lstsq) ** 2
    print("SE de la pérdida cuadrática media en test:", standard_error_mean(losses_test))
    """

    blank_probability = """\
    probability_answers = {
        "population_target": "",
        "estimator_random": "",
        "test_loss_role": "",
    }
    """
    solved_probability = """\
    probability_answers = {
        "population_target": "expected_squared_risk",
        "estimator_random": "theta_hat_and_test_risk",
        "test_loss_role": "estimate_population_risk",
    }
    """

    student_cells = [
        markdown("""
        # Lab 1: regresión lineal y descenso del gradiente

        Completa las funciones marcadas. No cambies sus nombres ni firmas. El
        autograder usará matrices distintas de las que aparecen en el notebook.
        """),
        code(COMMON_IMPORTS),
        code(setup),
        markdown("## Funciones requeridas"),
        code(student_functions),
        markdown("""
        ## Objetos probabilísticos

        Completa `probability_answers` con las etiquetas indicadas en el enunciado.
        Debes distinguir riesgo cuadrático esperado, estimador y estimación de test.
        """),
        code(blank_probability),
        markdown("""
        ## Experimento

        Escala usando solo entrenamiento. Compara tu implementación con el baseline,
        `np.linalg.lstsq` y `LinearRegression`; conserva resultados visibles.
        """),
        code(experiment),
        markdown("""
        ## Interpretación manual

        Explica qué muestra la convergencia y señala una limitación concreta del
        experimento. Una respuesta general sin referencia a tus resultados no basta.
        """),
    ]
    solution_cells = [
        markdown("# Lab 1 solución: regresión lineal y descenso del gradiente"),
        code(COMMON_IMPORTS),
        code(setup),
        markdown("## Funciones requeridas"),
        code(solution_functions),
        markdown("## Objetos probabilísticos"),
        code(solved_probability),
        markdown("## Experimento reproducible"),
        code(experiment),
        markdown("""
        ## Interpretación manual

        En esta partición, el MSE del baseline es aproximadamente 4716, mientras
        `lstsq`, descenso del gradiente y `LinearRegression` producen cerca de
        60.82. Además, la distancia entre los parámetros de `lstsq` y gradiente es
        del orden de $10^{-14}$ y la condición de ortogonalidad residual queda del
        orden de $10^{-12}$. Esas comparaciones muestran convergencia numérica, no
        solo una pérdida decreciente. El MSE de test estima el riesgo cuadrático
        esperado para nuevas observaciones de la población objetivo; no es ese
        riesgo poblacional exacto. El error estándar cercano a 19.98 muestra
        variación de las pérdidas individuales. También quedan incertidumbre por
        la partición y falta de validez externa: los datos son sintéticos y no
        incluyen faltantes, extremos ni cambio de distribución.
        """),
    ]
    write_notebook(
        LABS / "lab01_regresion_gradiente.ipynb",
        student_cells,
        "lab01",
        solution=False,
    )
    write_notebook(
        LABS / "lab01_regresion_gradiente_solucion.ipynb",
        solution_cells,
        "lab01",
        solution=True,
    )


def build_lab02() -> None:
    student_functions = """\
    def standardize_from_train(X_train, X_validation, X_test):
        # TODO: ajustar StandardScaler solo con X_train y transformar los tres conjuntos
        raise NotImplementedError


    def sigmoid(z):
        # TODO: implementar sigmoide vectorizada y estable
        raise NotImplementedError


    def log_loss_binary(y_true, proba, eps=1e-15):
        # TODO: implementar log-loss binaria con clipping
        raise NotImplementedError


    def ridge_closed_form(X, y, alpha):
        # TODO: usar X.T@X + alpha*P, con P[0, 0] = 0
        raise NotImplementedError


    def select_regularization_alpha(
        X_train,
        y_train,
        X_validation,
        y_validation,
        alphas,
        penalty="ridge",
    ):
        # TODO: comparar Ridge o Lasso usando únicamente el error de validación
        # Devuelve (mejor_alpha, {alpha: mse_validacion}).
        raise NotImplementedError


    def classification_metrics(y_true, proba, threshold=0.5):
        # TODO: devolver accuracy, precision, recall y f1
        raise NotImplementedError


    def bernoulli_standard_error(indicators):
        # TODO: error estándar plug-in de la media de indicadores 0/1
        raise NotImplementedError


    def choose_threshold_for_recall(y_true, proba, min_recall=0.90):
        # TODO: devolver el umbral más alto que cumpla el recall mínimo
        raise NotImplementedError
    """
    solution_functions = """\
    def standardize_from_train(X_train, X_validation, X_test):
        scaler = StandardScaler()
        train_scaled = scaler.fit_transform(np.asarray(X_train, dtype=float))
        validation_scaled = scaler.transform(np.asarray(X_validation, dtype=float))
        test_scaled = scaler.transform(np.asarray(X_test, dtype=float))
        return train_scaled, validation_scaled, test_scaled


    def sigmoid(z):
        z = np.asarray(z, dtype=float)
        out = np.empty_like(z, dtype=float)
        positive = z >= 0
        out[positive] = 1 / (1 + np.exp(-z[positive]))
        exp_z = np.exp(z[~positive])
        out[~positive] = exp_z / (1 + exp_z)
        return out


    def log_loss_binary(y_true, proba, eps=1e-15):
        y_true = np.asarray(y_true, dtype=float)
        proba = np.clip(np.asarray(proba, dtype=float), eps, 1 - eps)
        return float(
            -np.mean(y_true * np.log(proba) + (1 - y_true) * np.log(1 - proba))
        )


    def ridge_closed_form(X, y, alpha):
        X = np.asarray(X, dtype=float)
        y = np.asarray(y, dtype=float)
        penalty = np.eye(X.shape[1])
        penalty[0, 0] = 0.0
        return np.linalg.solve(X.T @ X + float(alpha) * penalty, X.T @ y)


    def select_regularization_alpha(
        X_train,
        y_train,
        X_validation,
        y_validation,
        alphas,
        penalty="ridge",
    ):
        if penalty not in {"ridge", "lasso"}:
            raise ValueError("penalty debe ser 'ridge' o 'lasso'")
        scores = {}
        for alpha in alphas:
            alpha = float(alpha)
            if penalty == "ridge":
                model = Ridge(alpha=alpha)
            else:
                model = Lasso(alpha=alpha, max_iter=20000, tol=1e-8)
            model.fit(X_train, y_train)
            prediction = model.predict(X_validation)
            scores[alpha] = float(mean_squared_error(y_validation, prediction))
        best_alpha = min(scores, key=scores.get)
        return best_alpha, scores


    def classification_metrics(y_true, proba, threshold=0.5):
        y_true = np.asarray(y_true).astype(int)
        pred = (np.asarray(proba, dtype=float) >= threshold).astype(int)
        return {
            "accuracy": float(accuracy_score(y_true, pred)),
            "precision": float(precision_score(y_true, pred, zero_division=0)),
            "recall": float(recall_score(y_true, pred, zero_division=0)),
            "f1": float(f1_score(y_true, pred, zero_division=0)),
        }


    def bernoulli_standard_error(indicators):
        indicators = np.asarray(indicators, dtype=float)
        if indicators.ndim != 1 or len(indicators) == 0:
            raise ValueError("indicators debe ser un vector no vacío")
        if not np.all(np.isin(indicators, [0.0, 1.0])):
            raise ValueError("indicators solo puede contener 0 y 1")
        p_hat = indicators.mean()
        return float(np.sqrt(p_hat * (1 - p_hat) / len(indicators)))


    def choose_threshold_for_recall(y_true, proba, min_recall=0.90):
        y_true = np.asarray(y_true).astype(int)
        proba = np.asarray(proba, dtype=float)
        candidates = np.unique(np.r_[0.0, proba, 1.0])
        valid = []
        for threshold in candidates:
            pred = (proba >= threshold).astype(int)
            recall = recall_score(y_true, pred, zero_division=0)
            if recall >= min_recall:
                valid.append(float(threshold))
        return max(valid) if valid else 0.0
    """
    blank_protocol = """\
    protocol_answers = {
        "fit_scaler_on": "",
        "select_regularization_on": "",
        "select_threshold_on": "",
        "test_set_role": "",
        "logistic_population_model": "",
        "validation_score_status": "",
    }
    probability_answers = protocol_answers
    """
    solved_protocol = """\
    protocol_answers = {
        "fit_scaler_on": "train_only",
        "select_regularization_on": "validation",
        "select_threshold_on": "validation",
        "test_set_role": "final_estimate",
        "logistic_population_model": "bernoulli_conditional",
        "validation_score_status": "random_estimator",
    }
    probability_answers = protocol_answers
    """
    regression_experiment = """\
    diabetes = load_diabetes()
    X_train, X_temp, y_train, y_temp = train_test_split(
        diabetes.data, diabetes.target, test_size=0.40, random_state=2105
    )
    X_validation, X_test, y_validation, y_test = train_test_split(
        X_temp, y_temp, test_size=0.50, random_state=2105
    )
    X_train_s, X_validation_s, X_test_s = standardize_from_train(
        X_train, X_validation, X_test
    )

    alphas = [0.01, 0.1, 1.0, 10.0]
    ridge_alpha, ridge_scores = select_regularization_alpha(
        X_train_s, y_train, X_validation_s, y_validation, alphas, penalty="ridge"
    )
    lasso_alpha, lasso_scores = select_regularization_alpha(
        X_train_s, y_train, X_validation_s, y_validation, alphas, penalty="lasso"
    )

    candidates = [
        ("ridge", ridge_alpha, ridge_scores[ridge_alpha]),
        ("lasso", lasso_alpha, lasso_scores[lasso_alpha]),
    ]
    selected_penalty, selected_alpha, selected_validation_mse = min(
        candidates, key=lambda row: row[2]
    )
    if selected_penalty == "ridge":
        selected_model = Ridge(alpha=selected_alpha)
    else:
        selected_model = Lasso(alpha=selected_alpha, max_iter=20000, tol=1e-8)
    selected_model.fit(X_train_s, y_train)
    test_prediction = selected_model.predict(X_test_s)

    print("selección:", selected_penalty, selected_alpha)
    print("MSE validación:", selected_validation_mse)
    print("MSE prueba, consultado una vez:", mean_squared_error(y_test, test_prediction))
    """
    classification_experiment = """\
    cancer = load_breast_cancer()
    X_train, X_temp, y_train, y_temp = train_test_split(
        cancer.data,
        cancer.target,
        test_size=0.40,
        random_state=2105,
        stratify=cancer.target,
    )
    X_validation, X_test, y_validation, y_test = train_test_split(
        X_temp,
        y_temp,
        test_size=0.50,
        random_state=2105,
        stratify=y_temp,
    )
    classifier = make_pipeline(
        StandardScaler(), LogisticRegression(max_iter=5000, random_state=2105)
    )
    classifier.fit(X_train, y_train)
    validation_proba = classifier.predict_proba(X_validation)[:, 1]
    selected_threshold = choose_threshold_for_recall(
        y_validation, validation_proba, min_recall=0.95
    )

    test_proba = classifier.predict_proba(X_test)[:, 1]
    test_pred = (test_proba >= selected_threshold).astype(int)
    print("umbral elegido en validación:", selected_threshold)
    print(
        "métricas finales de prueba:",
        classification_metrics(y_test, test_proba, threshold=selected_threshold),
    )
    print("SE plug-in de accuracy:", bernoulli_standard_error(test_pred == y_test))
    """

    student_cells = [
        markdown("""
        # Lab 2: regularización, validación y clasificación

        Completa las funciones sin cambiar sus nombres ni firmas. El autograder
        usará datos alternos y comprobará que entrenamiento, validación y prueba
        conservan papeles distintos.
        """),
        code(COMMON_IMPORTS),
        markdown("## Funciones requeridas"),
        code(student_functions),
        markdown("""
        ## Protocolo de evaluación

        Completa cada valor con una de las etiquetas permitidas en el enunciado.
        El protocolo incluye ahora el modelo poblacional Bernoulli y el carácter
        aleatorio de una métrica de validación.
        """),
        code(blank_protocol),
        markdown("""
        ## Experimento de regresión

        Construye particiones de entrenamiento, validación y prueba. Ajusta el
        escalador en entrenamiento, compara Ridge y Lasso en validación y consulta
        prueba una sola vez después de fijar el modelo y `alpha`.
        """),
        code(regression_experiment),
        markdown("""
        ## Experimento de clasificación

        Ajusta el modelo en entrenamiento, elige el umbral en validación y reporta
        las métricas finales en prueba.
        """),
        code(classification_experiment),
        markdown("""
        ## Interpretación manual

        Indica qué modelo o umbral recomendarías. Cita resultados de validación o
        prueba y comunica una limitación concreta antes de usarlo.
        """),
    ]
    solution_cells = [
        markdown("# Lab 2 solución: regularización, validación y clasificación"),
        code(COMMON_IMPORTS),
        markdown("## Funciones requeridas"),
        code(solution_functions),
        markdown("## Protocolo de evaluación"),
        code(solved_protocol),
        markdown("## Ridge y Lasso sobre `load_diabetes`"),
        code(regression_experiment),
        markdown("## Clasificación con `load_breast_cancer`"),
        code(classification_experiment),
        markdown("""
        ## Interpretación manual

        Para regresión recomendaría Ridge con `alpha=0.01`, seleccionado por un MSE
        de validación cercano a 2774; después de fijarlo, el MSE de prueba es cerca
        de 3007. Para clasificación usaría el umbral 0.813 elegido en validación:
        en prueba produce recall 0.958, precision 0.972 y F1 0.965. Esta regla es
        apropiada solo si la restricción de recall refleja el costo real de falsos
        negativos. Las métricas de prueba estiman desempeño poblacional bajo una
        distribución objetivo; la probabilidad del modelo estima, pero no equivale
        a, la probabilidad condicional verdadera. El error estándar plug-in de
        accuracy, aproximadamente 0.019, no incorpora selección de modelo ni cambio
        poblacional. Antes de uso clínico exigiría calibración, validación externa y
        análisis por subgrupos, pues `load_breast_cancer` es pequeño y curado.
        """),
    ]
    write_notebook(
        LABS / "lab02_regularizacion_clasificacion.ipynb",
        student_cells,
        "lab02",
        solution=False,
    )
    write_notebook(
        LABS / "lab02_regularizacion_clasificacion_solucion.ipynb",
        solution_cells,
        "lab02",
        solution=True,
    )


def main() -> None:
    build_lab01()
    build_lab02()
    print("OK: notebooks de Lab 1 y Lab 2 generados.")


if __name__ == "__main__":
    main()
