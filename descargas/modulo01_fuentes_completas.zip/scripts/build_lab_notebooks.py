#!/usr/bin/env python3
"""Genera las versiones estudiante y solución de los laboratorios 1 y 2."""

from __future__ import annotations

from pathlib import Path
from textwrap import dedent

import nbformat as nbf


ROOT = Path(__file__).resolve().parents[1]
LABS = ROOT / "laboratorios"

COMMON_IMPORTS = """\
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.datasets import load_diabetes, load_breast_cancer, make_regression
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression, Ridge, Lasso, LogisticRegression
from sklearn.preprocessing import StandardScaler, PolynomialFeatures
from sklearn.pipeline import make_pipeline
from sklearn.metrics import mean_squared_error, accuracy_score, precision_score, recall_score, f1_score, confusion_matrix, roc_auc_score
"""


def markdown(source: str):
    return nbf.v4.new_markdown_cell(dedent(source).strip())


def code(source: str):
    return nbf.v4.new_code_cell(dedent(source).strip())


def write_notebook(path: Path, cells: list) -> None:
    notebook = nbf.v4.new_notebook(cells=cells)
    notebook.metadata = {
        "kernelspec": {
            "display_name": "Python 3",
            "language": "python",
            "name": "python3",
        },
        "language_info": {"name": "python", "version": "3"},
    }
    nbf.write(notebook, path)


def build_lab01() -> None:
    setup = """\
    RNG = np.random.default_rng(2105)
    X_raw, y = make_regression(
        n_samples=120, n_features=3, noise=8.0, random_state=2105
    )
    X_train_raw, X_test_raw, y_train, y_test = train_test_split(
        X_raw, y, test_size=0.25, random_state=2105
    )
    """
    student_functions = """\
    def add_intercept(X):
        # TODO: devolver X con una primera columna de unos
        raise NotImplementedError


    def predict_linear(X, theta):
        # TODO: devolver X @ theta
        raise NotImplementedError


    def mse_loss(X, y, theta):
        # TODO: devolver 1/(2n) * suma de residuales al cuadrado
        raise NotImplementedError


    def normal_equation(X, y):
        # TODO: resolver mínimos cuadrados con np.linalg.lstsq
        # El nombre se conserva por compatibilidad con el autograder.
        raise NotImplementedError


    def mse_gradient(X, y, theta):
        # TODO: devolver el gradiente de la pérdida definida arriba
        raise NotImplementedError


    def gradient_descent(X, y, alpha=0.05, num_steps=1000):
        # TODO: devolver theta y una pérdida posterior a cada actualización
        raise NotImplementedError
    """
    solution_functions = """\
    def add_intercept(X):
        X = np.asarray(X, dtype=float)
        return np.c_[np.ones(X.shape[0]), X]


    def predict_linear(X, theta):
        return np.asarray(X, dtype=float) @ np.asarray(theta, dtype=float)


    def mse_loss(X, y, theta):
        X = np.asarray(X, dtype=float)
        y = np.asarray(y, dtype=float)
        theta = np.asarray(theta, dtype=float)
        residual = X @ theta - y
        return float(np.mean(residual**2) / 2)


    def normal_equation(X, y):
        X = np.asarray(X, dtype=float)
        y = np.asarray(y, dtype=float)
        return np.linalg.lstsq(X, y, rcond=None)[0]


    def mse_gradient(X, y, theta):
        X = np.asarray(X, dtype=float)
        y = np.asarray(y, dtype=float)
        theta = np.asarray(theta, dtype=float)
        return X.T @ (X @ theta - y) / len(y)


    def gradient_descent(X, y, alpha=0.05, num_steps=1000):
        X = np.asarray(X, dtype=float)
        y = np.asarray(y, dtype=float)
        theta = np.zeros(X.shape[1], dtype=float)
        history = []
        for _ in range(num_steps):
            theta = theta - alpha * mse_gradient(X, y, theta)
            loss = mse_loss(X, y, theta)
            if not np.isfinite(loss):
                raise FloatingPointError("La pérdida dejó de ser finita")
            history.append(loss)
        return theta, history
    """
    experiment = """\
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train_raw)
    X_test_scaled = scaler.transform(X_test_raw)
    X_train = add_intercept(X_train_scaled)
    X_test = add_intercept(X_test_scaled)

    theta_lstsq = normal_equation(X_train, y_train)
    theta_gd, history = gradient_descent(
        X_train, y_train, alpha=0.05, num_steps=2500
    )

    pred_lstsq = predict_linear(X_test, theta_lstsq)
    pred_gd = predict_linear(X_test, theta_gd)
    pred_baseline = np.full_like(y_test, y_train.mean(), dtype=float)

    model = LinearRegression().fit(X_train_scaled, y_train)
    pred_sklearn = model.predict(X_test_scaled)

    print("MSE baseline:", mean_squared_error(y_test, pred_baseline))
    print("MSE lstsq:", mean_squared_error(y_test, pred_lstsq))
    print("MSE descenso:", mean_squared_error(y_test, pred_gd))
    print("MSE sklearn:", mean_squared_error(y_test, pred_sklearn))
    print("||theta_lstsq - theta_gd||:", np.linalg.norm(theta_lstsq - theta_gd))
    print("||X.T @ residual_train||:", np.linalg.norm(X_train.T @ (y_train - X_train @ theta_lstsq)))
    """

    student_cells = [
        markdown("""
        # Lab 1: regresión lineal y descenso del gradiente

        Completa las funciones marcadas. No cambies sus nombres ni firmas. El
        autograder usará matrices distintas de las que aparecen en el notebook.
        """),
        code(COMMON_IMPORTS),
        code(setup),
        markdown("## Funciones requeridas"),
        code(student_functions),
        markdown("""
        ## Experimento

        Escala usando solo entrenamiento. Compara tu implementación con el baseline,
        `np.linalg.lstsq` y `LinearRegression`; conserva resultados visibles.
        """),
        code("# Escribe aquí el experimento reproducible."),
        markdown("""
        ## Interpretación manual

        Explica qué muestra la convergencia y señala una limitación concreta del
        experimento. Una respuesta general sin referencia a tus resultados no basta.
        """),
    ]
    solution_cells = [
        markdown("# Lab 1 solución: regresión lineal y descenso del gradiente"),
        code(COMMON_IMPORTS),
        code(setup),
        markdown("## Funciones requeridas"),
        code(solution_functions),
        markdown("## Experimento reproducible"),
        code(experiment),
        markdown("""
        ## Interpretación manual

        La pérdida disminuye y el vector obtenido por descenso queda cerca del de
        `lstsq`; además, ambos producen el mismo orden de error que `LinearRegression`
        y superan el predictor constante. Esto verifica la implementación en esta
        partición, no el desempeño sobre cualquier problema de regresión. Los datos
        son sintéticos y no ponen a prueba faltantes, valores extremos ni cambios de
        distribución.
        """),
    ]
    write_notebook(LABS / "lab01_regresion_gradiente.ipynb", student_cells)
    write_notebook(LABS / "lab01_regresion_gradiente_solucion.ipynb", solution_cells)


def build_lab02() -> None:
    student_functions = """\
    def standardize_from_train(X_train, X_validation, X_test):
        # TODO: ajustar StandardScaler solo con X_train y transformar los tres conjuntos
        raise NotImplementedError


    def sigmoid(z):
        # TODO: implementar sigmoide vectorizada y estable
        raise NotImplementedError


    def log_loss_binary(y_true, proba, eps=1e-15):
        # TODO: implementar log-loss binaria con clipping
        raise NotImplementedError


    def ridge_closed_form(X, y, alpha):
        # TODO: usar X.T@X + alpha*P, con P[0, 0] = 0
        raise NotImplementedError


    def select_regularization_alpha(
        X_train,
        y_train,
        X_validation,
        y_validation,
        alphas,
        penalty="ridge",
    ):
        # TODO: comparar Ridge o Lasso usando únicamente el error de validación
        # Devuelve (mejor_alpha, {alpha: mse_validacion}).
        raise NotImplementedError


    def classification_metrics(y_true, proba, threshold=0.5):
        # TODO: devolver accuracy, precision, recall y f1
        raise NotImplementedError


    def choose_threshold_for_recall(y_true, proba, min_recall=0.90):
        # TODO: devolver el umbral más alto que cumpla el recall mínimo
        raise NotImplementedError
    """
    solution_functions = """\
    def standardize_from_train(X_train, X_validation, X_test):
        scaler = StandardScaler()
        train_scaled = scaler.fit_transform(np.asarray(X_train, dtype=float))
        validation_scaled = scaler.transform(np.asarray(X_validation, dtype=float))
        test_scaled = scaler.transform(np.asarray(X_test, dtype=float))
        return train_scaled, validation_scaled, test_scaled


    def sigmoid(z):
        z = np.asarray(z, dtype=float)
        out = np.empty_like(z, dtype=float)
        positive = z >= 0
        out[positive] = 1 / (1 + np.exp(-z[positive]))
        exp_z = np.exp(z[~positive])
        out[~positive] = exp_z / (1 + exp_z)
        return out


    def log_loss_binary(y_true, proba, eps=1e-15):
        y_true = np.asarray(y_true, dtype=float)
        proba = np.clip(np.asarray(proba, dtype=float), eps, 1 - eps)
        return float(
            -np.mean(y_true * np.log(proba) + (1 - y_true) * np.log(1 - proba))
        )


    def ridge_closed_form(X, y, alpha):
        X = np.asarray(X, dtype=float)
        y = np.asarray(y, dtype=float)
        penalty = np.eye(X.shape[1])
        penalty[0, 0] = 0.0
        return np.linalg.solve(X.T @ X + float(alpha) * penalty, X.T @ y)


    def select_regularization_alpha(
        X_train,
        y_train,
        X_validation,
        y_validation,
        alphas,
        penalty="ridge",
    ):
        if penalty not in {"ridge", "lasso"}:
            raise ValueError("penalty debe ser 'ridge' o 'lasso'")
        scores = {}
        for alpha in alphas:
            alpha = float(alpha)
            if penalty == "ridge":
                model = Ridge(alpha=alpha)
            else:
                model = Lasso(alpha=alpha, max_iter=20000, tol=1e-8)
            model.fit(X_train, y_train)
            prediction = model.predict(X_validation)
            scores[alpha] = float(mean_squared_error(y_validation, prediction))
        best_alpha = min(scores, key=scores.get)
        return best_alpha, scores


    def classification_metrics(y_true, proba, threshold=0.5):
        y_true = np.asarray(y_true).astype(int)
        pred = (np.asarray(proba, dtype=float) >= threshold).astype(int)
        return {
            "accuracy": float(accuracy_score(y_true, pred)),
            "precision": float(precision_score(y_true, pred, zero_division=0)),
            "recall": float(recall_score(y_true, pred, zero_division=0)),
            "f1": float(f1_score(y_true, pred, zero_division=0)),
        }


    def choose_threshold_for_recall(y_true, proba, min_recall=0.90):
        y_true = np.asarray(y_true).astype(int)
        proba = np.asarray(proba, dtype=float)
        candidates = np.unique(np.r_[0.0, proba, 1.0])
        valid = []
        for threshold in candidates:
            pred = (proba >= threshold).astype(int)
            recall = recall_score(y_true, pred, zero_division=0)
            if recall >= min_recall:
                valid.append(float(threshold))
        return max(valid) if valid else 0.0
    """
    blank_protocol = """\
    protocol_answers = {
        "fit_scaler_on": "",
        "select_regularization_on": "",
        "select_threshold_on": "",
        "test_set_role": "",
    }
    """
    solved_protocol = """\
    protocol_answers = {
        "fit_scaler_on": "train_only",
        "select_regularization_on": "validation",
        "select_threshold_on": "validation",
        "test_set_role": "final_estimate",
    }
    """
    regression_experiment = """\
    diabetes = load_diabetes()
    X_train, X_temp, y_train, y_temp = train_test_split(
        diabetes.data, diabetes.target, test_size=0.40, random_state=2105
    )
    X_validation, X_test, y_validation, y_test = train_test_split(
        X_temp, y_temp, test_size=0.50, random_state=2105
    )
    X_train_s, X_validation_s, X_test_s = standardize_from_train(
        X_train, X_validation, X_test
    )

    alphas = [0.01, 0.1, 1.0, 10.0]
    ridge_alpha, ridge_scores = select_regularization_alpha(
        X_train_s, y_train, X_validation_s, y_validation, alphas, penalty="ridge"
    )
    lasso_alpha, lasso_scores = select_regularization_alpha(
        X_train_s, y_train, X_validation_s, y_validation, alphas, penalty="lasso"
    )

    candidates = [
        ("ridge", ridge_alpha, ridge_scores[ridge_alpha]),
        ("lasso", lasso_alpha, lasso_scores[lasso_alpha]),
    ]
    selected_penalty, selected_alpha, selected_validation_mse = min(
        candidates, key=lambda row: row[2]
    )
    if selected_penalty == "ridge":
        selected_model = Ridge(alpha=selected_alpha)
    else:
        selected_model = Lasso(alpha=selected_alpha, max_iter=20000, tol=1e-8)
    selected_model.fit(X_train_s, y_train)
    test_prediction = selected_model.predict(X_test_s)

    print("selección:", selected_penalty, selected_alpha)
    print("MSE validación:", selected_validation_mse)
    print("MSE prueba, consultado una vez:", mean_squared_error(y_test, test_prediction))
    """
    classification_experiment = """\
    cancer = load_breast_cancer()
    X_train, X_temp, y_train, y_temp = train_test_split(
        cancer.data,
        cancer.target,
        test_size=0.40,
        random_state=2105,
        stratify=cancer.target,
    )
    X_validation, X_test, y_validation, y_test = train_test_split(
        X_temp,
        y_temp,
        test_size=0.50,
        random_state=2105,
        stratify=y_temp,
    )
    classifier = make_pipeline(
        StandardScaler(), LogisticRegression(max_iter=5000, random_state=2105)
    )
    classifier.fit(X_train, y_train)
    validation_proba = classifier.predict_proba(X_validation)[:, 1]
    selected_threshold = choose_threshold_for_recall(
        y_validation, validation_proba, min_recall=0.95
    )

    test_proba = classifier.predict_proba(X_test)[:, 1]
    print("umbral elegido en validación:", selected_threshold)
    print(
        "métricas finales de prueba:",
        classification_metrics(y_test, test_proba, threshold=selected_threshold),
    )
    """

    student_cells = [
        markdown("""
        # Lab 2: regularización, validación y clasificación

        Completa las funciones sin cambiar sus nombres ni firmas. El autograder
        usará datos alternos y comprobará que entrenamiento, validación y prueba
        conservan papeles distintos.
        """),
        code(COMMON_IMPORTS),
        markdown("## Funciones requeridas"),
        code(student_functions),
        markdown("""
        ## Protocolo de evaluación

        Completa cada valor usando únicamente una de estas etiquetas:
        `train_only`, `validation` o `final_estimate`, según corresponda.
        """),
        code(blank_protocol),
        markdown("""
        ## Experimento de regresión

        Construye particiones de entrenamiento, validación y prueba. Ajusta el
        escalador en entrenamiento, compara Ridge y Lasso en validación y consulta
        prueba una sola vez después de fijar el modelo y `alpha`.
        """),
        code("# Escribe aquí el experimento de regresión."),
        markdown("""
        ## Experimento de clasificación

        Ajusta el modelo en entrenamiento, elige el umbral en validación y reporta
        las métricas finales en prueba.
        """),
        code("# Escribe aquí el experimento de clasificación."),
        markdown("""
        ## Interpretación manual

        Indica qué modelo o umbral recomendarías. Cita resultados de validación o
        prueba y comunica una limitación concreta antes de usarlo.
        """),
    ]
    solution_cells = [
        markdown("# Lab 2 solución: regularización, validación y clasificación"),
        code(COMMON_IMPORTS),
        markdown("## Funciones requeridas"),
        code(solution_functions),
        markdown("## Protocolo de evaluación"),
        code(solved_protocol),
        markdown("## Ridge y Lasso sobre `load_diabetes`"),
        code(regression_experiment),
        markdown("## Clasificación con `load_breast_cancer`"),
        code(classification_experiment),
        markdown("""
        ## Interpretación manual

        La recomendación debe usar el modelo y el `alpha` elegidos por validación,
        y el umbral que cumple el recall solicitado en validación. Las métricas de
        prueba se informan después de fijar esas decisiones. `load_breast_cancer`
        es un conjunto pequeño, limpio y clásico; este resultado no constituye una
        validación clínica externa ni demuestra calibración en otra población.
        """),
    ]
    write_notebook(
        LABS / "lab02_regularizacion_clasificacion.ipynb", student_cells
    )
    write_notebook(
        LABS / "lab02_regularizacion_clasificacion_solucion.ipynb", solution_cells
    )


def main() -> None:
    build_lab01()
    build_lab02()
    print("OK: notebooks de Lab 1 y Lab 2 generados.")


if __name__ == "__main__":
    main()
