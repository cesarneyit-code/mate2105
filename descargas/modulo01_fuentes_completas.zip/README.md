# Módulo 1: Regresión, optimización, regularización y clasificación

Este módulo cubre las semanas 2 a 6 de MATE-2105. Su función es construir el primer bloque fuerte del curso: modelos lineales, optimización, regularización, clasificación binaria y evaluación automatizada.

## Estructura

```text
modulo01_regresion_optimizacion/
├── capitulo01_regresion_lineal.qmd
├── capitulo02_descenso_gradiente.qmd
├── capitulo03_regularizacion_validacion.qmd
├── capitulo04_regresion_logistica.qmd
├── laboratorios/
├── notebooks/
├── slides/
├── recursos/
└── scripts/
```

## Render

```bash
quarto render
quarto render slides/semana02_presentacion.qmd
quarto render slides/semana03_presentacion.qmd
quarto render slides/semana04_presentacion.qmd
quarto render slides/semana05_presentacion.qmd
quarto render slides/semana06_presentacion.qmd
```

## Evaluación

El módulo incluye Lab 1, Lab 2 y Parcial 1. Para trabajar como estudiante, usa los notebooks publicados en `laboratorios/` y conserva las salidas visibles antes de entregar.

Los materiales privados de calificación no se distribuyen en los paquetes públicos.
