# Módulo 1: Regresión, optimización, regularización y clasificación

Este módulo cubre las semanas 2 a 6 de MATE-2105. Su función es construir el primer bloque fuerte del curso: modelos lineales, optimización, regularización, clasificación binaria y evaluación automatizada.

## Estructura

```text
modulo01_regresion_optimizacion/
├── capitulo01_regresion_lineal.qmd
├── capitulo02_descenso_gradiente.qmd
├── capitulo03_regularizacion_validacion.qmd
├── capitulo04_regresion_logistica.qmd
├── laboratorios/
├── notebooks/
├── slides/
├── docente/
├── recursos/
├── autograding/
└── scripts/
```

## Render

```bash
quarto render
quarto render slides/semana02_presentacion.qmd
quarto render slides/semana03_presentacion.qmd
quarto render slides/semana04_presentacion.qmd
quarto render slides/semana05_presentacion.qmd
quarto render slides/semana06_presentacion.qmd
```

## Autograding

Los laboratorios y el parcial tienen autograders Gradescope en `autograding/dist/`. También pueden ejecutarse localmente con:

```bash
python scripts/run_local_autograder.py lab01 laboratorios/lab01_regresion_gradiente_solucion.ipynb
python scripts/run_local_autograder.py lab02 laboratorios/lab02_regularizacion_clasificacion_solucion.ipynb
python scripts/run_local_autograder.py parcial01 laboratorios/parcial01_autograded_solucion.ipynb
```

La revisión manual queda restringida a interpretación breve y decisiones técnicas.
