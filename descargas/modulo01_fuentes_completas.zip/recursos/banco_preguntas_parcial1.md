# Banco de preguntas estructuradas Parcial 1

Estas preguntas están diseñadas para calificación rápida o automática.

## Probabilidad y estimación

1. Distingue parámetro poblacional, estimador y estimación en regresión lineal.
2. ¿Por qué $\mathbb E[Y\mid X=x]$ minimiza el riesgo cuadrático esperado?
3. ¿Cuál es la diferencia entre $R_P(f)$ y $\widehat R_m(f)$?
4. ¿Cómo cambia el error estándar de una media si el tamaño de muestra se multiplica por cuatro?
5. ¿Qué supuesto permite interpretar un promedio de test como estimador de desempeño futuro?
6. ¿Por qué una probabilidad logística estimada no es la probabilidad poblacional verdadera?

## Regresión lineal

7. Si `X` tiene forma `(n, p)` y `theta` tiene forma `(p,)`, ¿qué forma tiene `X @ theta`?
8. ¿Cuál es el gradiente de `J(theta)=1/(2n)||X theta - y||^2`?
9. ¿Qué sistema lineal resuelve la ecuación normal?
10. ¿Por qué no conviene usar `np.linalg.inv` explícitamente?

## Descenso del gradiente

11. Escribe la actualización de descenso del gradiente.
12. ¿Qué señal indica divergencia en una curva de pérdida?
13. ¿Por qué el escalamiento puede acelerar la convergencia?
14. ¿Por qué el escalamiento se ajusta solo con entrenamiento?

## Regularización

15. Escribe la pérdida Ridge.
16. ¿Qué efecto tiene aumentar `lambda`?
17. ¿Cuál es una diferencia práctica entre Ridge y Lasso?
18. ¿Por qué no se elige `lambda` con el conjunto de prueba?

## Clasificación

19. Escribe la función sigmoide.
20. ¿Qué representa el umbral en clasificación binaria?
21. ¿Cuándo recall puede ser más importante que precision?
22. ¿Por qué accuracy puede ser engañosa con clases desbalanceadas?

## Explicación corta

23. Un modelo tiene MSE bajo en entrenamiento y alto en validación. Explica el diagnóstico y una acción.
24. Un clasificador tiene accuracy 0.95 en un dataset con 95% negativos. Explica por qué esto puede no ser útil.
25. Un grupo usa el test set para escoger el grado polinomial. Explica el problema.
26. Un modelo supera el baseline por poco. ¿Qué evidencia adicional pedirías?
