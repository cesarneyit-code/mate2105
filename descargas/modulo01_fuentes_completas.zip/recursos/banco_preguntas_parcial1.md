# Banco de preguntas estructuradas Parcial 1

Estas preguntas están diseñadas para calificación rápida o automática.

## Regresión lineal

1. Si `X` tiene forma `(n, p)` y `theta` tiene forma `(p,)`, ¿qué forma tiene `X @ theta`?
2. ¿Cuál es el gradiente de `J(theta)=1/(2n)||X theta - y||^2`?
3. ¿Qué sistema lineal resuelve la ecuación normal?
4. ¿Por qué no conviene usar `np.linalg.inv` explícitamente?

## Descenso del gradiente

5. Escribe la actualización de descenso del gradiente.
6. ¿Qué señal indica divergencia en una curva de pérdida?
7. ¿Por qué el escalamiento puede acelerar la convergencia?
8. ¿Por qué el escalamiento se ajusta solo con entrenamiento?

## Regularización

9. Escribe la pérdida Ridge.
10. ¿Qué efecto tiene aumentar `lambda`?
11. ¿Cuál es una diferencia práctica entre Ridge y Lasso?
12. ¿Por qué no se elige `lambda` con el conjunto de prueba?

## Clasificación

13. Escribe la función sigmoide.
14. ¿Qué representa el umbral en clasificación binaria?
15. ¿Cuándo recall puede ser más importante que precision?
16. ¿Por qué accuracy puede ser engañosa con clases desbalanceadas?

## Explicación corta

17. Un modelo tiene MSE bajo en entrenamiento y alto en validación. Explica el diagnóstico y una acción.
18. Un clasificador tiene accuracy 0.95 en un dataset con 95% negativos. Explica por qué esto puede no ser útil.
19. Un grupo usa el test set para escoger el grado polinomial. Explica el problema.
20. Un modelo supera el baseline por poco. ¿Qué evidencia adicional pedirías?
